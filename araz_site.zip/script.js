function startMindMap() {
  alert("Zihin haritası modülü yakında eklenecek!");
}
